$(document).ready(function(){
    $('li').parentsUntil('.grand').css('border','1px solid black')
})












// $(document).ready(function(){
//     // $('#container').children().css('background-color', 'blue')
//     $('#container').find('p').css('background-color', 'lightblue')
    
// })






// $(document).ready(function(){
 
//     // $('#container').children().css('background-color','red')
//    //  $('#container').find('div').css('background-color','blue')
//     $('#container').eq(-1).css('background-color','lightblue')
    
// })
// $(document).ready(function(){
//     // $('p').next('div').css('background-color','red')
//     // $('p').nextAll('div').css('background-color','red')
//     // $('p').nextUntil('div').css('background-color','red')
//     // $('h2').prev().css('background-color','red')
//     // $('div').prevUntil('p').css('background-color','red')
    
// })





//javascript way
// function fun1(){
//     let x=document.getElementsByTagName('p')[0]
//     x.style.display= 'none'
//     if (x.style.display === 'none') {
//         x.style.display = 'inline';
//       } else {
//         x.style.display = 'none';
//       }
// }


// //jquery way
// $(document).ready(function(){       //first searching in dom
//     $('button').click(function(){       //second dom searching for button
//         $(this).hide()                   //third dom searching
//     })
   
    
// })












// $(document).ready(function(){       
//     $('button').click(function(){      
//         $('p').hide()                   
//     })
// })

















// // //document --> current document
// // //html page will be converted into document ---> head,body
// // $(document).ready(()=>{
// // //this code will exexcuted after fully loading the page
// // console.log("document is loaded")
// // })
// // ----------------------------------
// $(document).ready(function()
// {   console.log('now doc is ready')
//     $('button').dblclick(function()
//     {
//         confirm('do you want to continue')
//     })
// })

// // function fun1(){
// //     let btn=document.querySelector('#btn')
// //     btn.onclick=function(){
// //         alert('heloooo fkkdf')
// //     }
// // }
// // fun1()
