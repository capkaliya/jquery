// script.js-----------------------------------------

// // ///get request
// $(document).ready(function(){
//     $('button').click(function(){
//         $.ajax({
//             type: 'GET',
//             dataType: 'json',
//             url: 'http://localhost:3000/users',
//             success: function(res){
//                 console.log('successfully get data from json-server')
//                 let users = []              
//                 $.each(res, function(i, v){
//                     users += 
//                     `
//                     <div class="user">
//                         <p>Id: ${v.id}</p>
//                         <p>Username: ${v.username}</p>
//                         <p>Password: ${v.password}</p>
//                     </div>
//                     `
//                 })
//                 $('.container').append(users)                
//                 $('img').hide()
//             }
//         })
//     })
// })
// ///filter users --> with every keystroke it will filter users and show
// //matching users
// $(document).ready(function(){
//     $('#search').on('keyup', function(){
//         let searchKey = $(this).val().toLowerCase()
//         $('.user').filter(function(){
//             ///we will write logic for getting matching users
//             $(this).toggle($(this).text().toLowerCase().indexOf(searchKey) > -1)
//         })
//     })
// })
 
// /post request
$(document).ready(function(){
    $('button').click(function(){
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'http://localhost:3000/users',
            data: {
                id: 135,
                username: "dmj123",
                password: "dmj123"
              },
            success: function(res){
                console.log('successfully added record in json-server')              
                console.log(res)
            }
        })
    })
})