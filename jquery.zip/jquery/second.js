//pOST
$(document).ready(function(){
    $('button').click(function(){
        $.ajax({
            type:'POST',
            dataType:'json',
            url:"http://localhost:3000/profile",
            data:{
                userId:201,
                id:201,
                title:'basant',
                body:'djskhjkshkfsdkjfgksdghfksdf'
            },
               { userId:201,
                id:201,
                title:'basant',
                body:'djskhjkshkfsdkjfgksdghfksdf'}
            ,
            success:function(res){
                console.log('succes')
                console.log(res)

                
            }
        })


    })

})




//GET
// $(document).ready(function(){
//     $('button').click(function(){
//         $.ajax({
//             type:'GET',
//             dataType:'json',
//             url:"https://jsonplaceholder.typicode.com/posts",
//             success:function(res){
//                 console.log('response from server')
//                 $.each(res,function(i,record){
//                     console.log("User id:"+record.userId)
//                     console.log("id:"+record.id)
//                     console.log("Title:"+record.title)
//                     console.log("Body:"+record.body)

//                 })
//             }
//         })


//     })

// })



// //show hide password
// $(document).ready(function(){
//     $('button').click(function(){
//         if($('#pwd').attr('type')==='password'){
//             $('#pwd').attr('type','text')
//         }else{
//             $('#pwd').attr('type','password')
//         }

//     })

// })



// function fun1(){
//     let myp= document.createElement('p')
//     myp.innerHTML='this is new para added'
//     document.body.appendChild(myp)
// }


// $(document).ready(function(){
//    $('#start').click(function(){
//     //    $('p').append('this is jquery content')  
//     // $('p').prepend('  this is jquery content')  
//     // $('p').after('<h2>this is jquery content</h2>')  
//     // $('p').before('<h2>this is jquery content</h2>')  
//     // $('p').remove()  //totally remove element        
//     // $('div').empty()      //content delete
//     // $('div').css("background-color",'red').slideUp(2000).slideDown(2000)

//     console.log($('#un').attr('name'))

// })
// })



// $(document).ready(function(){
//     $('#start').click(function(){
//         // $('p').hide()
//         // $('p').show()
//         // $('p').toggle()
//         // $('p').fadeIn()
//         // $('p').fadeIn('slow')
//         // $('p').fadeIn(8000)
//         // $('span').fadeOut(3000)
//         // $('span').fadeToggle()
//         // $('div').slideUp()
//         // $('div').slideUp('slow')
//         // $('div').slideUp(4000)
//         // $('div').slideDown()
//         // $('div').slideToggle()
//         // $('div').animate({left:'250px',height:'+=300px',width:'+=300px'})
//         // $('div').animate({left:'250px',height:'300px',width:'300px'})
//         $('div').animate({
            
//             left:'250px',
//             height:'+=300px',
//             width:'+=300px',
//             opacity:0.2
            
//         },
//         4000
//         )
//     })
//     $('#stop').click(function(){
//         $('div').stop()
//     })
// })











// // $(document).ready(function(){
// //     console.log($('h1').html())             // it will get original
// //     $('h1').html('this is new contents')    //modify content
// //     console.log($('h1').html())         // get modified content


// //     /// get content of input control
// //     console.log($('#un').val())

// //     //cahnge
// //     $('h1').css({'background-color':'grey','color':'blue'})
// //     // $('h1').css('background-color','grey')
// //     console.log('current css for h1',$('h1').css('color'))

// //     //add css class
// //     $('h2').addClass('first')
// //     $('p').addClass('first')

// //     ///AFTER SOME TIME
// //     $('p').removeClass('first')

// //     //get width of paragraph
// //     console.log('widht of paragraph: '+ $('p').width())
// //     console.log('widht of span: '+ $('span').width())

// // })